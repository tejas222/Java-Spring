package com.xoriant.company;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.xoriant.company.config.MyConfig;
import com.xoriant.company.dao.EmpDaoImpl;
import com.xoriant.company.service.EmpService;
import com.xoriant.company.service.EmpServiceImpl;

public class Test {
public static void main(String[] args) {
	
	ApplicationContext ac = new AnnotationConfigApplicationContext(MyConfig.class);
	EmpService es = ac.getBean(EmpServiceImpl.class);
	 
	es.saveEmployee();
	 
}
}
