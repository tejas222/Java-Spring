package com.xoriant.company.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.xoriant.company.dao;com.xoriant.company.service")

public class MyConfig {
	
    
}
