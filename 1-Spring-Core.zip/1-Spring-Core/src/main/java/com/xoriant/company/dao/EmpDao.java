package com.xoriant.company.dao;

public interface EmpDao {
	
	void save();
}