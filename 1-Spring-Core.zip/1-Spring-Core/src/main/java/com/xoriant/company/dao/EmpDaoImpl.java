package com.xoriant.company.dao;

import org.springframework.stereotype.Repository;

@Repository
public class EmpDaoImpl implements EmpDao {
	
	@Override
	public void save() {
		System.out.println(">>>> DAO>>> Saving Employee");
	}
}
