package com.xoriant.company.service;

public interface EmpService {
	
	void saveEmployee();
}
