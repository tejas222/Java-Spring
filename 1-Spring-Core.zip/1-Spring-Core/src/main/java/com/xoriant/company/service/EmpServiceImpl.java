package com.xoriant.company.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.xoriant.company.dao.EmpDao;

@Service
public class EmpServiceImpl implements EmpService{
	
	@Autowired
	private EmpDao empDao;

	@Override
	public void saveEmployee() {
		System.out.println(">>> Service::: saveEmp");
		
	}
	
	
	

}
